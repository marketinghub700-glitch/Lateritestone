import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import {
  Phone, MessageCircle, Truck, Mountain, Ruler, Zap, ShieldCheck,
  PackageCheck, MapPin, Star, Quote, Calculator, ArrowRight, Check
} from "lucide-react";

import hero from "@/assets/hero-laterite.jpg";
import quarry from "@/assets/quarry.jpg";
import villa from "@/assets/villa.jpg";
import wall from "@/assets/wall.jpg";
import lorry from "@/assets/lorry.jpg";
import stones from "@/assets/stones.jpg";
import stoneProduct from "@/assets/laterite-stone-kannur.jpg.asset.json";
import site from "@/assets/site.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Laterite Stone Kannur - Supply in Kerala & Bangalore" },
      { name: "description", content: "Direct quarry laterite stone supply. Uniform size, bulk orders, fast delivery across Kerala & Bangalore. Get today's rate on WhatsApp." },
    ],
  }),
  component: Home,
});

const PHONE = "+919961861664";
const WHATSAPP = "919961861664";
const waLink = (msg: string) => `https://wa.me/${WHATSAPP}?text=${encodeURIComponent(msg)}`;

function Home() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <Nav />
      <Hero />
      <TrustStrip />
      <About />
      <StoneTypes />
      <CalculatorSection />
      <WhyUs />
      <Gallery />
      <Areas />
      <Testimonials />
      <FinalCTA />
      <Footer />
      <FloatingWhatsApp />
      <StickyMobileBar />
    </div>
  );
}

/* ----------------- NAV ----------------- */
function Nav() {
  return (
    <header className="sticky top-0 z-40 border-b border-border/60 bg-background/90 backdrop-blur">
      <div className="container-x flex h-16 items-center justify-between">
        <a href="#top" className="flex items-center gap-2">
          <div className="grid h-9 w-9 place-items-center rounded-md bg-primary text-primary-foreground font-display text-lg">R</div>
          <div className="leading-tight">
            <div className="font-display text-base">RED EARTH CO.</div>
            <div className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">Laterite Stone Supply</div>
          </div>
        </a>
        <nav className="hidden md:flex items-center gap-8 text-sm font-medium">
          <a href="#stones" className="hover:text-primary">Stones</a>
          <a href="#calculator" className="hover:text-primary">Calculator</a>
          <a href="#why" className="hover:text-primary">Why Us</a>
          <a href="#gallery" className="hover:text-primary">Projects</a>
          <a href="#areas" className="hover:text-primary">Areas</a>
        </nav>
        <a href={`tel:${PHONE}`} className="hidden md:inline-flex items-center gap-2 rounded-md bg-charcoal px-4 py-2 text-sm font-semibold text-primary-foreground hover:bg-charcoal/90">
          <Phone className="h-4 w-4" /> Call Now
        </a>
      </div>
    </header>
  );
}

/* ----------------- HERO ----------------- */
function Hero() {
  return (
    <section id="top" className="relative isolate overflow-hidden">
      <div className="absolute inset-0 -z-10">
        <img src={hero} alt="Premium laterite stone wall construction in Kerala" width={1920} height={1080} className="h-full w-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-r from-charcoal/90 via-charcoal/70 to-charcoal/40" />
      </div>

      <div className="container-x relative pt-20 pb-28 md:pt-32 md:pb-40 text-primary-foreground">
        <div className="inline-flex items-center gap-2 rounded-full border border-primary-foreground/20 bg-primary-foreground/10 px-3 py-1 text-xs font-semibold uppercase tracking-wider backdrop-blur animate-fade-up">
          <span className="h-2 w-2 rounded-full bg-primary" />
          Direct from Quarry • Kerala & Bangalore
        </div>

        <h1 className="mt-6 max-w-4xl font-display text-5xl md:text-7xl lg:text-8xl uppercase animate-fade-up" style={{ animationDelay: "0.05s" }}>
          Premium Laterite<br />
          <span className="text-primary">Stone Supply</span><br />
          Across Kerala
        </h1>

        <p className="mt-6 max-w-2xl text-lg md:text-xl text-primary-foreground/85 animate-fade-up" style={{ animationDelay: "0.15s" }}>
          Direct Quarry Supply • Uniform Size • Fast Delivery • Bulk Orders Available
        </p>

        <div className="mt-8 flex flex-wrap gap-3 animate-fade-up" style={{ animationDelay: "0.25s" }}>
          <a href={waLink("Hi, I'd like today's quarry rate for laterite stones.")} className="inline-flex items-center gap-2 rounded-md bg-primary px-6 py-4 text-base font-bold uppercase tracking-wide text-primary-foreground shadow-stone transition hover:translate-y-[-2px] hover:bg-terracotta-dark">
            Get Today's Quarry Rate <ArrowRight className="h-4 w-4" />
          </a>
          <a href={waLink("Hi, I'm interested in bulk laterite supply.")} className="inline-flex items-center gap-2 rounded-md bg-whatsapp px-6 py-4 text-base font-bold uppercase tracking-wide text-primary-foreground shadow-stone transition hover:translate-y-[-2px] hover:bg-whatsapp-dark">
            <MessageCircle className="h-5 w-5" /> WhatsApp Us
          </a>
        </div>

        <div className="mt-12 grid grid-cols-3 max-w-xl gap-3 animate-fade-up" style={{ animationDelay: "0.35s" }}>
          {[
            { icon: PackageCheck, label: "Bulk Supply" },
            { icon: Zap, label: "Fast Delivery" },
            { icon: ShieldCheck, label: "Contractor Preferred" },
          ].map((b) => (
            <div key={b.label} className="flex flex-col items-start gap-2 rounded-lg border border-primary-foreground/15 bg-primary-foreground/10 p-3 backdrop-blur">
              <b.icon className="h-5 w-5 text-primary" />
              <span className="text-xs md:text-sm font-semibold">{b.label}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function TrustStrip() {
  const items = ["10,000+ Lorry Loads Delivered", "500+ Projects Supplied", "Direct Quarry Owner", "ON TIME DELIVERY", "Same-Day Quotation"];
  return (
    <div className="border-y border-border bg-charcoal text-primary-foreground">
      <div className="container-x flex flex-wrap items-center justify-center gap-x-10 gap-y-3 py-4 text-xs md:text-sm font-semibold uppercase tracking-wider">
        {items.map((i) => (
          <span key={i} className="flex items-center gap-2">
            <Check className="h-4 w-4 text-primary" /> {i}
          </span>
        ))}
      </div>
    </div>
  );
}

/* ----------------- ABOUT ----------------- */
function About() {
  return (
    <section id="about" className="container-x grid gap-12 py-20 md:py-28 md:grid-cols-2 md:items-center">
      <div>
        <span className="text-xs font-bold uppercase tracking-[0.25em] text-primary">About Red Earth Co.</span>
        <h2 className="mt-3 text-4xl md:text-5xl uppercase">Built on red earth.<br />Trusted by builders.</h2>
        <p className="mt-6 text-lg text-muted-foreground leading-relaxed">
          Red Earth Co. is a Kerala-based direct quarry supplier of premium laterite stones (chenkallu). For over a decade we've supplied contractors, architects, and villa owners with consistently sized, dense, hand-picked stone — delivered on time, in full lorry loads.
        </p>
        <ul className="mt-6 grid grid-cols-2 gap-3 text-sm font-semibold">
          {["Reliable supply chain", "Uniform stone sizing", "Fast transport coordination", "Kerala & Bangalore projects"].map((x) => (
            <li key={x} className="flex items-start gap-2"><Check className="mt-0.5 h-4 w-4 text-primary" /> {x}</li>
          ))}
        </ul>
      </div>
      <div className="relative">
        <img src={quarry} alt="Aerial view of laterite stone quarry" width={1280} height={960} loading="lazy" className="aspect-[4/3] w-full rounded-xl object-cover shadow-deep" />
        <div className="absolute -bottom-6 -left-6 hidden md:block rounded-xl border border-border bg-card p-5 shadow-stone">
          <div className="font-display text-4xl text-primary">10+</div>
          <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Years Quarry Experience</div>
        </div>
      </div>
    </section>
  );
}

/* ----------------- STONE TYPES ----------------- */
const STONES = [
  { size: '7" × 7" × 13"', usage: "Compound walls, partition walls", price: "₹32 – ₹38 / piece", popular: false },
  { size: '8" × 8" × 14"', usage: "Load-bearing walls, villas", price: "₹48 – ₹55 / piece", popular: true },
  { size: '15" × 6" × 4"', usage: "Heavy walls, foundation", price: "₹62 – ₹70 / piece", popular: false },
];

function StoneTypes() {
  return (
    <section id="stones" className="bg-sand py-20 md:py-28">
      <div className="container-x">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <span className="text-xs font-bold uppercase tracking-[0.25em] text-primary">Sizes & Pricing</span>
            <h2 className="mt-3 text-4xl md:text-5xl uppercase">Pick your stone.<br />Get the best rate.</h2>
          </div>
          <p className="max-w-md text-muted-foreground">Prices vary by load size and delivery distance. Get an exact quotation in 5 minutes on WhatsApp.</p>
        </div>

        <div className="mt-12 grid gap-6 md:grid-cols-3">
          {STONES.map((s) => (
            <div key={s.size} className={`group relative flex flex-col rounded-xl border bg-card p-6 transition hover:-translate-y-1 hover:shadow-deep ${s.popular ? "border-primary ring-2 ring-primary/20" : "border-border"}`}>
              {s.popular && <span className="absolute -top-3 left-6 rounded-full bg-primary px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-primary-foreground">Most Ordered</span>}
              <div className="aspect-[4/3] overflow-hidden rounded-lg bg-muted">
                <img src={stoneProduct.url} alt="laterite stone kannur" width={800} height={600} loading="lazy" className="h-full w-full object-cover transition duration-500 group-hover:scale-105" />
              </div>
              <div className="mt-5 font-display text-2xl">{s.size}</div>
              <div className="mt-1 text-sm text-muted-foreground">{s.usage}</div>
              <div className="mt-4 font-display text-3xl text-primary">{s.price}</div>
              <a href={waLink(`Hi, I'd like a quote for ${s.size} laterite stones.`)} className="mt-5 inline-flex items-center justify-center gap-2 rounded-md bg-whatsapp px-4 py-3 text-sm font-bold uppercase tracking-wide text-primary-foreground hover:bg-whatsapp-dark">
                <MessageCircle className="h-4 w-4" /> WhatsApp Enquiry
              </a>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ----------------- CALCULATOR ----------------- */
function CalculatorSection() {
  const [length, setLength] = useState(30);
  const [height, setHeight] = useState(10);
  const [size, setSize] = useState('8" × 8" × 14"');

  const result = useMemo(() => {
    const sizes: Record<string, { l: number; h: number; price: number }> = {
      '7" × 7" × 13"': { l: 13, h: 7, price: 35 },
      '8" × 8" × 14"': { l: 14, h: 8, price: 52 },
      '15" × 6" × 4"': { l: 15, h: 6, price: 65 },
    };
    const cfg = sizes[size];
    const wallSqFt = length * height;
    const stoneSqFt = (cfg.l * cfg.h) / 144;
    const count = Math.ceil((wallSqFt / stoneSqFt) * 1.05); // 5% wastage
    const lorries = Math.max(1, Math.ceil(count / 800));
    const cost = count * cfg.price;
    return { count, lorries, cost };
  }, [length, height, size]);

  return (
    <section id="calculator" className="relative overflow-hidden bg-charcoal py-20 md:py-28 text-primary-foreground">
      <div className="absolute inset-0 grain opacity-30" />
      <div className="container-x relative grid gap-12 md:grid-cols-2 md:items-center">
        <div>
          <span className="text-xs font-bold uppercase tracking-[0.25em] text-primary">Free Tool</span>
          <h2 className="mt-3 text-4xl md:text-5xl uppercase">Laterite Stone<br/>Calculator</h2>
          <p className="mt-4 max-w-md text-primary-foreground/70">Enter your wall dimensions and stone size. We'll estimate stones, lorry loads and cost instantly.</p>

          <div className="mt-8 space-y-5">
            <Field label="Wall Length (ft)" value={length} onChange={setLength} />
            <Field label="Wall Height (ft)" value={height} onChange={setHeight} />
            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-primary-foreground/60">Stone Size</label>
              <div className="mt-2 grid grid-cols-3 gap-2">
                {Object.keys({ '7" × 7" × 13"': 0, '8" × 8" × 14"': 0, '15" × 6" × 4"': 0 }).map((s) => (
                  <button key={s} onClick={() => setSize(s)} className={`rounded-md border px-3 py-3 text-xs font-semibold transition ${size === s ? "border-primary bg-primary text-primary-foreground" : "border-primary-foreground/20 hover:border-primary"}`}>{s}</button>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="rounded-2xl border border-primary-foreground/15 bg-primary-foreground/5 p-6 md:p-8 backdrop-blur">
          <div className="flex items-center gap-2 text-primary">
            <Calculator className="h-5 w-5" />
            <span className="text-xs font-bold uppercase tracking-wider">Estimated Result</span>
          </div>
          <div className="mt-6 grid grid-cols-1 gap-4">
            <Stat label="Stones Required" value={result.count.toLocaleString()} unit="pieces" />
            <Stat label="Approx Lorry Loads" value={result.lorries.toString()} unit={result.lorries === 1 ? "lorry" : "lorries"} />
            <Stat label="Estimated Cost" value={`₹${result.cost.toLocaleString("en-IN")}`} unit="approx" highlight />
          </div>
          <p className="mt-6 text-xs text-primary-foreground/60">* Includes 5% wastage. Lorry size ~800 stones. Final pricing depends on delivery distance and current quarry rate.</p>
          <a href={waLink(`Hi, I need pricing for a wall ${length}ft × ${height}ft using ${size} stones. Calculator estimates ${result.count} stones.`)} className="mt-6 flex items-center justify-center gap-2 rounded-md bg-whatsapp px-5 py-4 text-sm font-bold uppercase tracking-wide hover:bg-whatsapp-dark">
            <MessageCircle className="h-5 w-5" /> Get Exact Quarry Pricing on WhatsApp
          </a>
        </div>
      </div>
    </section>
  );
}

function Field({ label, value, onChange }: { label: string; value: number; onChange: (n: number) => void }) {
  return (
    <div>
      <label className="text-xs font-bold uppercase tracking-wider text-primary-foreground/60">{label}</label>
      <input type="number" value={value} onChange={(e) => onChange(Math.max(0, Number(e.target.value)))} className="mt-2 w-full rounded-md border border-primary-foreground/20 bg-primary-foreground/5 px-4 py-3 font-display text-2xl text-primary-foreground outline-none focus:border-primary" />
    </div>
  );
}

function Stat({ label, value, unit, highlight = false }: { label: string; value: string; unit: string; highlight?: boolean }) {
  return (
    <div className={`flex items-baseline justify-between rounded-lg border px-4 py-4 ${highlight ? "border-primary bg-primary/10" : "border-primary-foreground/10 bg-primary-foreground/5"}`}>
      <span className="text-xs font-semibold uppercase tracking-wider text-primary-foreground/70">{label}</span>
      <span className="text-right">
        <span className={`font-display text-3xl ${highlight ? "text-primary" : ""}`}>{value}</span>
        <span className="ml-2 text-xs text-primary-foreground/60">{unit}</span>
      </span>
    </div>
  );
}

/* ----------------- WHY US ----------------- */
const WHY = [
  { icon: Mountain, title: "Direct Quarry Supply", desc: "We own the source. No middlemen, no markups." },
  { icon: Ruler, title: "Uniform Size", desc: "Hand-picked stones, consistent dimensions every load." },
  { icon: Truck, title: "Fast Delivery", desc: "Same-day or next-day lorry dispatch across Kerala." },
  { icon: PackageCheck, title: "Bulk Orders", desc: "From 1 lorry to 100+ loads, scaled to your project." },
  { icon: ShieldCheck, title: "Reliable Transport", desc: "Trusted lorry network with on-time guarantees." },
  { icon: Zap, title: "Emergency Supply", desc: "Urgent site requirement? Call us — we deliver." },
];

function WhyUs() {
  return (
    <section id="why" className="container-x py-20 md:py-28">
      <div className="max-w-2xl">
        <span className="text-xs font-bold uppercase tracking-[0.25em] text-primary">Why Choose Us</span>
        <h2 className="mt-3 text-4xl md:text-5xl uppercase">Contractors keep coming back.</h2>
      </div>
      <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {WHY.map((w) => (
          <div key={w.title} className="group rounded-xl border border-border bg-card p-6 transition hover:-translate-y-1 hover:border-primary hover:shadow-stone">
            <div className="grid h-12 w-12 place-items-center rounded-lg bg-primary/10 text-primary transition group-hover:bg-primary group-hover:text-primary-foreground">
              <w.icon className="h-6 w-6" />
            </div>
            <h3 className="mt-5 font-display text-xl uppercase">{w.title}</h3>
            <p className="mt-2 text-sm text-muted-foreground">{w.desc}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

/* ----------------- GALLERY ----------------- */
const GALLERY = [
  { src: villa, label: "Kerala Villa", span: "row-span-2" },
  { src: wall, label: "Compound Wall", span: "" },
  { src: quarry, label: "Quarry Site", span: "" },
  { src: lorry, label: "Lorry Loading", span: "" },
  { src: site, label: "Construction Site", span: "row-span-2" },
  { src: stones, label: "Stone Texture", span: "" },
];

function Gallery() {
  return (
    <section id="gallery" className="bg-sand py-20 md:py-28">
      <div className="container-x">
        <div className="max-w-2xl">
          <span className="text-xs font-bold uppercase tracking-[0.25em] text-primary">Project Gallery</span>
          <h2 className="mt-3 text-4xl md:text-5xl uppercase">From quarry to villa.</h2>
        </div>
        <div className="mt-12 grid grid-cols-2 md:grid-cols-3 auto-rows-[180px] md:auto-rows-[240px] gap-3 md:gap-4">
          {GALLERY.map((g, i) => (
            <div key={i} className={`group relative overflow-hidden rounded-xl ${g.span}`}>
              <img src={g.src} alt={g.label} width={800} height={600} loading="lazy" className="h-full w-full object-cover transition duration-700 group-hover:scale-110" />
              <div className="absolute inset-0 bg-gradient-to-t from-charcoal/80 via-transparent to-transparent" />
              <div className="absolute bottom-3 left-4 text-sm font-bold uppercase tracking-wider text-primary-foreground">{g.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ----------------- AREAS ----------------- */
const AREAS = [
  { name: "Kannur", state: "Kerala", primary: true },
  { name: "Calicut", state: "Kerala", primary: true },
  { name: "Wayanad", state: "Kerala" },
  { name: "Kasaragod", state: "Kerala" },
  { name: "Malappuram", state: "Kerala" },
  { name: "Bangalore", state: "Karnataka", primary: true },
];

function Areas() {
  return (
    <section id="areas" className="container-x py-20 md:py-28">
      <div className="grid gap-12 md:grid-cols-2 md:items-center">
        <div>
          <span className="text-xs font-bold uppercase tracking-[0.25em] text-primary">Delivery Areas</span>
          <h2 className="mt-3 text-4xl md:text-5xl uppercase">Supplying across<br/>Kerala & Bangalore.</h2>
          <p className="mt-4 text-muted-foreground max-w-md">Our lorry network covers North Kerala extensively, with regular long-haul deliveries to Bangalore construction sites.</p>
          <div className="mt-8 grid grid-cols-2 gap-3">
            {AREAS.map((a) => (
              <div key={a.name} className={`flex items-center gap-3 rounded-lg border p-4 transition ${a.primary ? "border-primary bg-primary/5" : "border-border bg-card"}`}>
                <MapPin className={`h-5 w-5 ${a.primary ? "text-primary" : "text-muted-foreground"}`} />
                <div>
                  <div className="font-display text-lg">{a.name}</div>
                  <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{a.state}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="relative aspect-square overflow-hidden rounded-2xl border border-border bg-card shadow-deep">
          <div className="absolute inset-0 bg-gradient-to-br from-sand via-background to-accent" />
          <svg viewBox="0 0 400 400" className="absolute inset-0 h-full w-full">
            {/* stylized map shape */}
            <path d="M120,40 Q80,100 90,180 Q100,260 140,320 Q200,380 260,340 Q320,300 310,220 Q300,140 250,80 Q190,30 120,40 Z"
              fill="oklch(0.55 0.18 35 / 0.12)" stroke="oklch(0.55 0.18 35)" strokeWidth="2" />
            {[
              { x: 140, y: 110, label: "Kasaragod" },
              { x: 150, y: 160, label: "Kannur" },
              { x: 170, y: 200, label: "Wayanad" },
              { x: 145, y: 230, label: "Calicut" },
              { x: 175, y: 280, label: "Malappuram" },
              { x: 290, y: 310, label: "Bangalore" },
            ].map((p) => (
              <g key={p.label}>
                <circle cx={p.x} cy={p.y} r="6" fill="oklch(0.55 0.18 35)">
                  <animate attributeName="r" values="6;9;6" dur="2s" repeatCount="indefinite" />
                </circle>
                <text x={p.x + 12} y={p.y + 4} className="fill-charcoal" style={{ fontSize: 11, fontWeight: 700 }}>{p.label}</text>
              </g>
            ))}
          </svg>
          <div className="absolute bottom-4 left-4 rounded-lg bg-card/90 px-3 py-2 text-xs font-bold uppercase tracking-wider backdrop-blur">
            <Truck className="inline h-4 w-4 text-primary mr-1" /> 6+ Service Hubs
          </div>
        </div>
      </div>
    </section>
  );
}

/* ----------------- TESTIMONIALS ----------------- */
const TESTIMONIALS = [
  { name: "Rajesh Menon", role: "Contractor, Calicut", text: "Best laterite supply in North Kerala. 12 lorry loads delivered on time for our villa project. Stone size was uniform throughout." },
  { name: "Ar. Priya Nair", role: "Architect, Kochi", text: "We've specified Red Earth Co. on 5 residential projects. Their stones have the colour and density our designs demand." },
  { name: "Suresh Kumar", role: "Builder, Bangalore", text: "Long-haul delivery to Bangalore was smooth. Pricing was transparent and the WhatsApp coordination saved us hours." },
];

function Testimonials() {
  return (
    <section className="bg-charcoal py-20 md:py-28 text-primary-foreground">
      <div className="container-x">
        <div className="max-w-2xl">
          <span className="text-xs font-bold uppercase tracking-[0.25em] text-primary">Contractor Voices</span>
          <h2 className="mt-3 text-4xl md:text-5xl uppercase">Trusted on<br/>500+ project sites.</h2>
        </div>
        <div className="mt-12 grid gap-6 md:grid-cols-3">
          {TESTIMONIALS.map((t) => (
            <div key={t.name} className="relative rounded-xl border border-primary-foreground/10 bg-primary-foreground/5 p-6 backdrop-blur">
              <Quote className="h-8 w-8 text-primary" />
              <p className="mt-4 text-primary-foreground/90 leading-relaxed">"{t.text}"</p>
              <div className="mt-6 flex items-center justify-between border-t border-primary-foreground/10 pt-4">
                <div>
                  <div className="font-display text-lg">{t.name}</div>
                  <div className="text-xs uppercase tracking-wider text-primary-foreground/60">{t.role}</div>
                </div>
                <div className="flex gap-0.5">
                  {Array.from({ length: 5 }).map((_, i) => <Star key={i} className="h-4 w-4 fill-primary text-primary" />)}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ----------------- FINAL CTA ----------------- */
function FinalCTA() {
  return (
    <section className="relative isolate overflow-hidden py-24 md:py-32">
      <div className="absolute inset-0 -z-10">
        <img src={wall} alt="" width={1280} height={960} loading="lazy" className="h-full w-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-r from-terracotta-dark/95 to-terracotta/90" />
      </div>
      <div className="container-x text-center text-primary-foreground">
        <h2 className="font-display text-4xl md:text-7xl uppercase">Need Reliable Laterite<br/>Stone Supply?</h2>
        <p className="mx-auto mt-6 max-w-2xl text-lg md:text-xl text-primary-foreground/90">Get Fast Delivery & Best Quarry Rates Today.</p>
        <div className="mt-10 flex flex-wrap justify-center gap-4">
          <a href={`tel:${PHONE}`} className="inline-flex items-center gap-2 rounded-md bg-charcoal px-8 py-5 text-base font-bold uppercase tracking-wider hover:bg-charcoal/90">
            <Phone className="h-5 w-5" /> Call Now
          </a>
          <a href={waLink("Hi, I need laterite stone supply.")} className="inline-flex items-center gap-2 rounded-md bg-whatsapp px-8 py-5 text-base font-bold uppercase tracking-wider hover:bg-whatsapp-dark">
            <MessageCircle className="h-5 w-5" /> WhatsApp Now
          </a>
        </div>
      </div>
    </section>
  );
}

/* ----------------- FOOTER ----------------- */
function Footer() {
  return (
    <footer className="bg-charcoal text-primary-foreground/80">
      <div className="container-x grid gap-10 py-16 md:grid-cols-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="grid h-9 w-9 place-items-center rounded-md bg-primary text-primary-foreground font-display">R</div>
            <div className="font-display text-base text-primary-foreground">RED EARTH CO.</div>
          </div>
          <p className="mt-4 text-sm">Premium laterite stone supplier serving Kerala & Bangalore since 2014.</p>
          <p className="mt-4 text-xs uppercase tracking-wider text-primary-foreground/50"></p>
        </div>

        <div>
          <h4 className="font-display text-sm uppercase text-primary-foreground">Contact</h4>
          <ul className="mt-4 space-y-2 text-sm">
            <li><a href={`tel:${PHONE}`} className="hover:text-primary">+91 99618 61664</a></li>
            <li><a href={waLink("Hi Red Earth Co.")} className="hover:text-primary">WhatsApp Chat</a></li>
            <li>hello@lateritestone.com</li>
            <li>Kannur, Kerala — 670001</li>
          </ul>
        </div>

        <div>
          <h4 className="font-display text-sm uppercase text-primary-foreground">Service Areas</h4>
          <ul className="mt-4 space-y-2 text-sm">
            {AREAS.map((a) => <li key={a.name}>{a.name}, {a.state}</li>)}
          </ul>
        </div>

        <div>
          <h4 className="font-display text-sm uppercase text-primary-foreground">Find Us</h4>
          <div className="mt-4 aspect-video overflow-hidden rounded-lg border border-primary-foreground/10">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d125320.71!2d75.27!3d11.87!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0!2sKannur!5e0!3m2!1sen!2sin!4v1700000000000"
              width="100%" height="100%" style={{ border: 0 }} loading="lazy" referrerPolicy="no-referrer-when-downgrade" title="Red Earth Co. Location"
            />
          </div>
          <div className="mt-4 flex gap-3">
            {["FB", "IG", "YT"].map((s) => (
              <a key={s} href="#" className="grid h-9 w-9 place-items-center rounded-md border border-primary-foreground/20 text-xs font-bold hover:bg-primary hover:text-primary-foreground hover:border-primary">{s}</a>
            ))}
          </div>
        </div>
      </div>
      <div className="border-t border-primary-foreground/10">
        <div className="container-x py-5 text-center text-xs text-primary-foreground/50">© {new Date().getFullYear()} Red Earth Co. All rights reserved.</div>
      </div>
    </footer>
  );
}

/* ----------------- FLOATING & STICKY ----------------- */
function FloatingWhatsApp() {
  return (
    <a href={waLink("Hi, I'd like laterite stone pricing.")} aria-label="WhatsApp"
      className="fixed bottom-24 md:bottom-6 right-5 z-50 grid h-14 w-14 place-items-center rounded-full bg-whatsapp text-primary-foreground shadow-deep animate-pulse-ring hover:bg-whatsapp-dark">
      <MessageCircle className="h-7 w-7" />
    </a>
  );
}

function StickyMobileBar() {
  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 grid grid-cols-2 md:hidden border-t border-border bg-card shadow-deep">
      <a href={`tel:${PHONE}`} className="flex items-center justify-center gap-2 bg-charcoal py-4 text-sm font-bold uppercase text-primary-foreground">
        <Phone className="h-4 w-4" /> Call
      </a>
      <a href={waLink("Hi, I need laterite stone pricing.")} className="flex items-center justify-center gap-2 bg-whatsapp py-4 text-sm font-bold uppercase text-primary-foreground">
        <MessageCircle className="h-4 w-4" /> WhatsApp
      </a>
    </div>
  );
}
