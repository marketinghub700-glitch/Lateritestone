import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";

import appCss from "../styles.css?url";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold text-foreground">404</h1>
        <h2 className="mt-4 text-xl font-semibold">Page not found</h2>
        <div className="mt-6">
          <Link to="/" className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90">Go home</Link>
        </div>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  const router = useRouter();
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-xl font-semibold">This page didn't load</h1>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <button onClick={() => { router.invalidate(); reset(); }} className="rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground">Try again</button>
          <a href="/" className="rounded-md border border-input bg-background px-4 py-2 text-sm font-medium">Go home</a>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "Laterite Stone Kannur - Supply in Kerala & Bangalore" },
      { name: "description", content: "Direct quarry laterite stone supply. Uniform size, bulk orders, fast delivery across Kerala & Bangalore. Get today's rate on WhatsApp." },
      { name: "keywords", content: "laterite stone Kerala, laterite stone supplier, quarry stone Bangalore, chenkallu, laterite blocks, bulk laterite supply" },
      { property: "og:title", content: "Laterite Stone Kannur - Supply in Kerala & Bangalore" },
      { property: "og:description", content: "Direct quarry laterite stone supply. Uniform size, bulk orders, fast delivery across Kerala & Bangalore. Get today's rate on WhatsApp." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: "Laterite Stone Kannur - Supply in Kerala & Bangalore" },
      { name: "twitter:description", content: "Direct quarry laterite stone supply. Uniform size, bulk orders, fast delivery across Kerala & Bangalore. Get today's rate on WhatsApp." },
      { property: "og:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/fee60b05-b5b4-4b9a-a91e-779d7f759c86/id-preview-6fadb328--3c992031-0e8d-4fa4-af63-f94bbf4461cd.lovable.app-1781511792774.png" },
      { name: "twitter:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/fee60b05-b5b4-4b9a-a91e-779d7f759c86/id-preview-6fadb328--3c992031-0e8d-4fa4-af63-f94bbf4461cd.lovable.app-1781511792774.png" },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      { rel: "stylesheet", href: "https://fonts.googleapis.com/css2?family=Archivo+Black&family=Inter:wght@400;500;600;700;800&display=swap" },
    ],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@graph": [
            {
              "@type": "LocalBusiness",
              "@id": "https://lateritestone.com/#business",
              "name": "Red Earth Co.",
              "url": "https://lateritestone.com/",
              "telephone": "+91 99618 61664",
              "email": "hello@lateritestone.com",
              "description": "Laterite stone supplier providing direct quarry supply, bulk orders and delivery for construction projects across Kerala and Bangalore.",
              "address": {
                "@type": "PostalAddress",
                "addressLocality": "Kannur",
                "addressRegion": "Kerala",
                "postalCode": "670001",
                "addressCountry": "IN"
              },
            "areaServed": [
              {
                "@type": "State",
                "name": "Kerala"
              },
              {
                "@type": "City",
                "name": "Bangalore"
              }
            ],
            "priceRange": "₹₹",
            "currenciesAccepted": "INR"
            },
            {
              "@type": "WebSite",
              "@id": "https://lateritestone.com/#website",
              "url": "https://lateritestone.com/",
              "name": "Laterite Stone",
              "publisher": {
                "@id": "https://lateritestone.com/#business"
              }
            },
            {
              "@type": "WebPage",
              "@id": "https://lateritestone.com/#webpage",
              "url": "https://lateritestone.com/",
              "name": "Laterite Stone Supplier in Kannur, Kerala",
              "description": "Premium laterite stone supplied directly from quarry for construction projects across Kerala and Bangalore.",
              "isPartOf": {
                "@id": "https://lateritestone.com/#website"
              },
              "about": {
                "@id": "https://lateritestone.com/#business"
              }
            },
            {
              "@type": "Service",
              "@id": "https://lateritestone.com/#service",
              "name": "Laterite Stone Supply and Delivery",
              "description": "Direct quarry supply of laterite stone for residential and commercial construction projects.",
              "provider": {
                "@id": "https://lateritestone.com/#business"
              },
              "areaServed": [
                {
                  "@type": "State",
                  "name": "Kerala"
                },
                {
                  "@type": "City",
                  "name": "Bangalore"
                }
              ],
              "serviceType": "Laterite Stone Supply"
            },
            {
              "@type": "Product",
              "@id": "https://lateritestone.com/#product-7x7x13",
              "name": "Laterite Stone 7 x 7 x 13 inch",
              "description": "Laterite stone suitable for construction, compound walls and partition walls.",
              "brand": {
                "@type": "Brand",
                "name": "Red Earth Co."
              },
              "offers": {
                "@type": "AggregateOffer",
                "priceCurrency": "INR",
                "lowPrice": "32",
                "highPrice": "38",
                "availability": "https://schema.org/InStock",
                "url": "https://lateritestone.com/"
              }
            },
            {
              "@type": "Product",
              "@id": "https://lateritestone.com/#product-8x8x14",
              "name": "Laterite Stone 8 x 8 x 14 inch",
              "description": "Laterite stone suitable for construction and masonry projects.",
              "brand": {
                "@type": "Brand",
                "name": "Red Earth Co."
              },
              "offers": {
                "@type": "AggregateOffer",
                "priceCurrency": "INR",
                "lowPrice": "48",
                "highPrice": "55",
                "availability": "https://schema.org/InStock",
                "url": "https://lateritestone.com/"
              }
            },
            {
              "@type": "Product",
              "@id": "https://lateritestone.com/#product-15x6x4",
              "name": "Laterite Stone 15 x 6 x 4 inch",
              "description": "Laterite stone suitable for construction and masonry projects.",
              "brand": {
                "@type": "Brand",
                "name": "Red Earth Co."
              },
              "offers": {
                "@type": "AggregateOffer",
                "priceCurrency": "INR",
                "lowPrice": "62",
                "highPrice": "70",
                "availability": "https://schema.org/InStock",
                "url": "https://lateritestone.com/"
              }
            }
          ]
        })
      }
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head><HeadContent /></head>
      <body>{children}<Scripts /></body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();
  return (
    <QueryClientProvider client={queryClient}>
      <Outlet />
    </QueryClientProvider>
  );
}
