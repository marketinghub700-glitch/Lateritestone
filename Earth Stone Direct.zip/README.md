# Earth Stone Direct

Create a modern, highly conversion-optimized one-page website for a laterite stone supply company called “Red Earth Co.”

The website should look premium, trustworthy, earthy, and construction-industry focused. Use a terracotta red, sand beige, white, and charcoal black color palette. The design must feel strong, reliable, and practical — not corporate or techy.

Target audience:

- Contractors

- Builders

- Site engineers

- Villa owners

- Architects

- Construction companies in Kerala and Bangalore

Primary goal:

Generate WhatsApp enquiries and phone calls for bulk laterite stone orders.

Style:

- Premium industrial design

- Large construction visuals

- Realistic quarry and construction imagery

- Clean typography

- Strong CTA buttons

- Mobile-first responsive layout

- Fast-loading design

- Sticky WhatsApp button

- Smooth scrolling animations

- SEO-friendly structure

Website sections:

1. HERO SECTION

- Full-width hero section with a premium laterite stone construction background image

- Headline:

  “Premium Laterite Stone Supply Across Kerala”

- Subheadline:

  “Direct Quarry Supply • Uniform Size • Fast Delivery • Bulk Orders Available”

- CTA buttons:

  “Get Today’s Quarry Rate”

  “WhatsApp Us”

- Add trust badges:

  “Bulk Supply”

  “Fast Delivery”

  “Contractor Preferred”

2. ABOUT SECTION

Short premium brand introduction about Red Earth Co.

Mention:

- Reliable supply

- Uniform stone sizing

- Fast transport coordination

- Serving Kerala & Bangalore projects

3. STONE TYPES & PRICING

Create premium cards showing:

- Stone size

- Usage type

- Approx pricing

- WhatsApp enquiry button

4. INTERACTIVE CALCULATOR SECTION

Add a “Laterite Stone Calculator”

Inputs:

- Wall length

- Wall height

- Stone size

Outputs:

- Estimated number of stones

- Approx lorry loads

- Estimated cost

Below result:

“Get Exact Quarry Pricing on WhatsApp”

5. WHY CHOOSE US

Use modern icon cards for:

- Direct Quarry Supply

- Uniform Size

- Fast Delivery

- Bulk Orders

- Reliable Transport

- Emergency Supply

6. PROJECT GALLERY

Create a premium masonry-style gallery with:

- Kerala villas

- Compound walls

- Quarry images

- Lorry loading

- Construction sites

7. DELIVERY AREAS

Display Kerala and Bangalore service locations:

- Kannur

- Calicut

- Wayanad

- Kasaragod

- Malappuram

- Bangalore

Use map-style section visuals.

8. TESTIMONIALS

Display contractor-style testimonials with realistic names and project types.

9. FINAL CTA SECTION

Strong closing section with:

Headline:

“Need Reliable Laterite Stone Supply?”

Subheadline:

“Get Fast Delivery & Best Quarry Rates Today”

Buttons:

- Call Now

- WhatsApp Now

10. FOOTER

Include:

- Contact details

- WhatsApp

- Service areas

- Google Maps embed

- GST details

- Social icons

Additional requirements:

- Add floating WhatsApp button

- Add sticky mobile CTA bar

- Optimize for high conversion

- Add subtle hover effects

- Add scroll animations

- Use realistic laterite construction images

- Create premium construction industry feel

- Ensure mobile responsiveness

- SEO optimized headings and structure

- Focus heavily on lead generation and trust building

The website should feel like a professional construction material supplier capable of handling large contractor orders immediately.

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://red-earth-builder-buddy.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/3c992031-0e8d-4fa4-af63-f94bbf4461cd).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
